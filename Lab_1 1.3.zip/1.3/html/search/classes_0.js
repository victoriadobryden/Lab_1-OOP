var searchData=
[
  ['dequeue_16',['Dequeue',['../class_dequeue.html',1,'']]]
];
