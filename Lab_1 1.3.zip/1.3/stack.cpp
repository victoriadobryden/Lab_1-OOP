﻿#include <iostream>
#include <stack>
using namespace std;

/**
 * \brief class List that stores ints
 * Double-connected list with standart pointers
 */
class List
{
    struct Node
    {
        /**
         * \brief Node constructor
         * @param a data
         * @param next next item in list
         * @param prev prev item in list
         */
        Node(int a, Node* next, Node* prev) : data(a), pNext(next), pPrev(prev) {};
        Node* pPrev;
        Node* pNext;
        int data;
    };
    int size = 0;       ///< size of the list
    Node* head = NULL;  ///< first item in the list
    Node* tail = NULL;  ///< last item in the list
    
    public:
    /** 
     * Add element to the end of the list
     * @param a element to add
     */
    void add(int a) {
        size++;
        Node* newnode = new Node(a, nullptr, nullptr);

        if (head == NULL)
        {
            head = newnode;
            tail = newnode;
        }
        else {

            Node* it = head;

            while (it->pNext != NULL)
            {
                it = it->pNext;


            }
            it->pNext = newnode;
            newnode->pPrev = it;
            tail = newnode;
        }
    }
    /// Get the size of the list
    /// @return number of elements in the list
    int get_size() const {
        return size;
    }
    void print() const
    {
        Node* it = head;
        while (it != NULL)
        {
            cout << it->data << ' ';
            it = it->pNext;
        }
        cout << endl;
    }
    /// Find the given element in the list
    /// @param a element to search
    /// @return True of element is found
    void find(int a)
    {
        Node* it = head;
        int i = 0;
        while (it != NULL)
        {

            if (it->data == a)
            {

                cout << i << endl;

            }
            it = it->pNext;
            i++;
        }
    }
    // TODO
    ~List()
    {
        Node* c = NULL;

        Node* it = head;
        while (it->pNext != NULL)
        {
            c = it;
            it = it->pNext;

            delete c;
        }

        head = NULL;
        cout << "spysok is empty" << endl;
    }
    void removelast()
    {
        Node* prev_el = tail->pPrev;
        delete tail;
        tail = prev_el;
        tail->pNext = NULL;
        --size;
    }
    int getlast() const
    {
        if (tail == NULL) return 0;
        else return tail->data;
    }
    int getfirst() const
    {
        if (head == NULL) return 0;
        else return head->data;
    }
    void removefirst() 
    {
        head = head->pNext;
        delete head->pPrev;
        head->pPrev = NULL;
        --size;
    }
};

/**
 * \brief Interface for the stack subclasses
 */
class StackInterface
{
public: 
    /**
     * \brief Removes the element from the stack
     * @return Value of the popped element
     */
    virtual int pop_back() = 0;
    /**
     * \brief Adds the element to the stack
     * @param Value to push 
     */
    virtual void push_back(int a) = 0;
    /// Get the size of the stack
    /// @return number of elements in the stack
    virtual int size() const = 0;
    /// Check if the stack is empty
    /// @return True if the stack is empty
    virtual bool empty() const = 0;
};

/**
 * \brief Stack based on List
 * Stack with basic functionality of adding and removing elements. Uses list to store data
 */
class Stack: public StackInterface
{
    List l;
public:
    
    void print() const
    {
        l.print();
    }
    
    void push_back(int a) override
    {
        l.add(a);
    };
    
    int pop_back() override
    {
        int b = l.getlast();
        l.removelast();
        return  b;

    };
    int size() const override
    {
        return l.get_size();
    }
    bool empty() const override
    {
        return l.get_size() == 0;
    }
};

/**
 * \brief Stack based on Array
 * Stack with basic functionality of adding and removing elements. Uses array to store data
 */
class StackArray: public StackInterface
{
private:
    int* ar = NULL;
    int ar_size = 0;
public:
    void print() const
    {
        for (int i = 0; i < ar_size; ++i) {
            cout << ar[i] << " ";
        }
        cout << endl;
    }
    
    void push_back(int a) override
    {
        int* new_ar = new int [ar_size + 1];
        for (int i = 0; i < ar_size; ++i) {
            new_ar[i] = ar[i];
        }
        new_ar[ar_size] = a;
        ++ar_size;
        if (ar != NULL) delete [] ar;
        ar = new_ar;
    };
    
    int pop_back() override
    {
        int val = ar[ar_size - 1];
        --ar_size;
        return val;
    };
    int size() const override
    {
        return ar_size;
    }
    bool empty() const override
    {
        return ar_size == 0;
    }
    ~StackArray()
    {
        delete [] ar;
    }

};

/**
 * \brief Stack based on STD stack
 * Stack with basic functionality of adding and removing elements. Uses STD library
 */
class StackSTD: public StackInterface
{
private:
    std::stack<int> s;
public:
    void print() const
    {
        // TODO
        std::stack<int> copy_s = s;
        while (!copy_s.empty())
        {
            cout << copy_s.top() << " ";
            copy_s.pop();
        }
        cout << endl;
    }
    
    void push_back(int a) override
    {
        s.push(a);
    };
    
    int pop_back() override
    {
        int val = s.top();
        s.pop();
        return val;
    };
    int size() const override
    {
        return s.size();
    }
    bool empty() const override
    {
        return s.empty();
    }
};
/**
 * \brief Interface for the queue subclasses
 */
class QueueInterface
{
public:
    /**
     * \brief Adds the element to the Queue
     * @param Value to push 
     */
    virtual void push_back(int a) = 0;
    /**
     * \brief Removes the element from the Queue
     * @return Value of the popped element
     */
    virtual int pop_front() = 0;
    /// Get the size of the Queue
    /// @return number of elements in the Queue
    virtual int size() const = 0;
    /// Check if the Queue is empty
    /// @return True if the Queue is empty
    virtual bool empty() const = 0;
};
/**
 * \brief Queue based on List
 * Queue with basic functionality of adding and removing elements. Uses list to store data
 */
class Queue : public QueueInterface
{
    List l;
public:
    void print() const
    {
        l.print();
    }

    void push_back(int a) override
    {
        l.add(a);
    };
    int pop_front() override
    {
        int b = l.getfirst();
        l.removefirst();
        return  b;
    };
    int size() const override
    {
        return l.get_size();
    }
    bool empty() const override
    {
        return l.get_size() == 0;
    }
};

/**
 * \brief Dequeue based on List
 * Dequeue with basic functionality of adding and removing elements. Uses list to store data
 */
class Dequeue : public QueueInterface, StackInterface
{
private:
    List l;
public:
    
    void push_back(int a) override
    {
        l.add(a);
    };
    int pop_front() override
    {
        int b = l.getfirst();
        l.removefirst();
        return  b;

    };
    int pop_back() override
    {
        int b = l.getlast();
        l.removelast();
        return  b;
    };
    void print() const
    {
        l.print();
    }
    int size() const override
    {
        return l.get_size();
    }
    bool empty() const override
    {
        return l.get_size() == 0;
    }
};


int main(int argc, char* argv[])
{
    setlocale(LC_ALL, "ru");
    List l;
    l.add(1);
    l.print();
    cout << "--- Stack on list ---" << endl;
    Stack s;
    s.push_back(1);
    s.push_back(2);
    s.push_back(3);
    s.push_back(4);
    s.push_back(5);

    s.print();
    s.pop_back();
    s.pop_back();
    s.print();
    cout << "--- Queue on list ---" << endl;
    Queue q;
    q.push_back(1);
    q.push_back(2);
    q.push_back(3);
    q.push_back(4);
    q.push_back(5);

    q.print();
    q.pop_front();
    q.pop_front();
    q.print();
    cout << "--- Deueue on list ---" << endl;
    Dequeue dq;
    dq.push_back(1);
   
    dq.push_back(2);
    dq.print();
    dq.pop_front();
    dq.print();
    cout << "--- Stack on array ---" << endl;
    StackArray sa;
    sa.push_back(1);
    sa.push_back(2);
    sa.push_back(3);
    sa.push_back(4);
    sa.push_back(5);

    sa.print();
    sa.pop_back();
    sa.pop_back();
    sa.print();

    cout << "--- Stack on std stack ---" << endl;
    StackSTD st;
    st.push_back(1);
    st.push_back(2);
    st.push_back(3);
    st.push_back(4);
    st.push_back(5);

    st.print();
    st.pop_back();
    st.pop_back();
    st.print();

    return 0;
}